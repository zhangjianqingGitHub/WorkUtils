package com.example.dragrecyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView mMainRecyclerView;
    private MainAdapter mMainAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initView();

    }


    private void initView() {
        mMainRecyclerView = findViewById(R.id.main_recycler_view);
        mMainRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));
//        MyItemTouchHelper itemTouchHelper=new MyItemTouchHelper(new MyItemTouchHelperCallBack());

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new MyItemTouchHelperCallBack());
        itemTouchHelper.attachToRecyclerView(mMainRecyclerView);

        mMainRecyclerView.addItemDecoration(new MyItemDecoration(Utils.dpToPx(this, 20)));

        mMainAdapter = new MainAdapter(getData());
        mMainRecyclerView.setAdapter(mMainAdapter);

    }


    private List<String> getData() {

        List<String> listData = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            listData.add(i + "");
        }
        return listData;
    }

}