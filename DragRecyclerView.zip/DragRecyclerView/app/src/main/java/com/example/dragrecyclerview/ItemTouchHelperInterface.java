package com.example.dragrecyclerview;

/**
 * Author: 张建青 zhangjianqing@ziroom.com
 * Time Created at 2021/9/6.
 */
public interface ItemTouchHelperInterface {
    void onItemSelect();
}
