package com.example.dragrecyclerview;

import android.graphics.Rect;
import android.util.Log;
import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

/**
 * Author: 张建青 zhangjianqing@ziroom.com
 * Time Created at 2021/9/6.
 */
public class MyItemDecoration extends RecyclerView.ItemDecoration {
    private final int space;
    public MyItemDecoration(int space) {
        this.space = space;
    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {

//        RecyclerView.getChildLayoutPosition();
//        RecyclerView.getChildAdapterPosition();
        int adapterPosition = parent.getChildAdapterPosition(view);
        if (adapterPosition != 0 && adapterPosition != 1) {
            outRect.top = space;
        }
        if (adapterPosition % 2 == 0) {
            outRect.right = space / 2;
            outRect.left = space;
        } else {
            outRect.left = space / 2;
            outRect.right = space;
        }
    }
}
