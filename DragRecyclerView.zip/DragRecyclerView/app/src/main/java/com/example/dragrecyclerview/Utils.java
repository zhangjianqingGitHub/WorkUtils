package com.example.dragrecyclerview;

import android.content.Context;

/**
 * Author: 张建青 zhangjianqing@ziroom.com
 * Time Created at 2021/9/3.
 */
public class Utils {

    public static int dpToPx(Context context, int dps) {
        return Math.round(context.getResources().getDisplayMetrics().density * dps);
    }
}
