package com.example.dragrecyclerview;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ItemTouchHelper;

public class MyItemTouchHelper extends ItemTouchHelper {

    public MyItemTouchHelper(@NonNull Callback callback) {
        super(callback);
    }


}

